/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
import {
  i
} from "./chunk.TLFIX76K.js";

// src/components/intersection-observer/intersection-observer.styles.ts
var intersection_observer_styles_default = i`
  :host {
    display: contents;
  }
`;

export {
  intersection_observer_styles_default
};
